#ifndef BITSIZE_H
#define BITSIZE_H

//The amount of components and systems that can be created
#define BITSIZE 32

#endif
